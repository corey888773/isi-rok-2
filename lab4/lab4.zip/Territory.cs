﻿namespace Main;

public class Territory
{
    public string? Id { get; set; }
    public string? TerritoryDescription { get; set; }
    public string? RegionId { get; set; }
    
    public Territory()
    {
    }
}