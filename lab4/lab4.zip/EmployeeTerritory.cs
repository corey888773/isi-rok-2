﻿namespace Main;

public class EmployeeTerritory
{
    public string? EmployeeId { get; set; }
    public string? TerritoryId { get; set; }
    
    public EmployeeTerritory(){}
}