﻿namespace Main;

public class Region
{
    public string? Id { get; set; }
    public string? RegionDescription { get; set; }
    
    public Region(){}
}