﻿namespace Main
{
    class Lab06
    {
        public static void Main(string[] args)
        {
            
        }
    }
}