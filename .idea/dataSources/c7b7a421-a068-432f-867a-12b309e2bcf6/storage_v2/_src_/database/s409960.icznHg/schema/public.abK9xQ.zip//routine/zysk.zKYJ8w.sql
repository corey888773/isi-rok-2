create function zysk(idx character) returns integer
    language plpgsql
as
$$
DECLARE 
wynik numeric(7,2);
BEGIN
SELECT p.koszt-SUM(z.sztuk*cz.koszt) INTO wynik
FROM pudelka p
JOIN zawartosc z USING(idpudelka)
JOIN czekoladki cz USING(idczekoladki)
WHERE p.idpudelka = idx;

RETURN wynik;
END;
$$;

alter function zysk(char) owner to s400513;

