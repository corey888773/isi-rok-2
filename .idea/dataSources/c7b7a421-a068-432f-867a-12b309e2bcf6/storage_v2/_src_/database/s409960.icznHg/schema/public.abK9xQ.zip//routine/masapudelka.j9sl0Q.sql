create function masapudelka(idx character) returns integer
    language plpgsql
as
$$
DECLARE 
wynik INT;
BEGIN
SELECT SUM(c.masa*z.sztuk) INTO wynik
FROM pudelka p
JOIN zawartosc z USING(idpudelka)
JOIN czekoladki cz USING(idczekoladki)
WHERE p.idpudelka = idx;
RETURN wynik;
END;
$$;

alter function masapudelka(char) owner to s400513;

